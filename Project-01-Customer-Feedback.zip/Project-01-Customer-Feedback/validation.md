# Validation & QA Notes

All review IDs refer to the included synthetic `customer_reviews.csv`.

## Sentiment rubric

- **Positive:** Overall praise; minor non-material caveats allowed.
- **Negative:** Clear dissatisfaction without meaningful positive counterpoint.
- **Neutral:** Mostly indifferent description without distinct strong praise or criticism.
- **Mixed:** Contains explicit positive praise **and** explicit negative criticism.

### R024: disputed label

- **First NotebookLM result:** Neutral.
- **Second NotebookLM result:** Mixed.
- **Reason:** Praises coffee while criticising cake quality and noise. Mixed is consistent with the above rubric.
- **Caveat:** Labelling is interpretive, not an objective property of the text.

## Revised issue frequencies (non-exclusive tags)

| Category | Count | Supporting IDs | Inclusion rule |
| --- | ---: | --- | --- |
| Food/drink quality or serving temperature | 8 | R001, R007, R009, R013, R022, R024, R025, R028 | Explicit unfavourable product/temperature feedback |
| Order or dietary instruction error | 5 | R002, R010, R012, R018, R027 | Incorrect, omitted or forgotten requested item/modifier |
| Service delay / failure to acknowledge | 5 | R001, R010, R016, R018, R025 | Delay explicitly criticised by reviewer |
| Price or value complaint | 5 | R007, R015, R021, R025, R028 | Explicit price or portion-value dissatisfaction |
| Cleanliness / hygiene | 2 | R005, R019 | Dirty premises or hair in food |
| Dietary stockout | 1 | R030 | Advertised GF option unavailable |

Not counted as negative waits: R023 (15-minute wait, but positive assessment of staff's handling). R019 was mis-grouped under order errors in NotebookLM's second analysis, but belongs under hygiene and complaint handling.

## Follow-up checks and discrepancies

1. **R005:** sticky tables and dirty cups are cleanliness issues; second AI audit incorrectly included it in food/coffee quality.
2. **R019:** hair in salad plus poor response is a hygiene/service-recovery problem, not an inaccurate order.
3. **R027:** requested extra-hot latte and no onion; order specifications were not followed. Do not double-count as a general coffee standard defect in this rubric.
4. **R029:** praise of regular customer treatment does not demonstrate faster service; second audit used it in a fast-service list.
5. **R022:** reviewer wonders whether beans or staff changed; speculation is not proof.
6. **R024:** mixed under defined rubric.
7. **R023:** positive handling of a table wait should not be presented as an unresolved negative experience.

## Interpretation safeguards

- Category counts overlap across reviews; sum of counts is not the number of unique complaints/customers.
- This 30-review synthetic dataset cannot establish actual business prevalence, causal drivers or measurable churn.
- Star ratings alone are insufficient for sentiment classification.
- Review evidence is evidence of *what a fictional customer said*, not independent proof of operations.
- The QA outcome is a documented judgement call, not a certified evaluation of NotebookLM's accuracy.
