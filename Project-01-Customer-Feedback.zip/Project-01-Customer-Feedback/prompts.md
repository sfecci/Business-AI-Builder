# Prompts used in the workflow

## 1. Synthetic dataset creation (condensed)

> Act as a Customer Experience Analyst for a fictional café in Adelaide, South Australia. Produce 30 synthetic reviews written in Australian English, covering coffee, food, service, wait times, prices, dietary needs, cleanliness and order accuracy. Use columns `review_id`, `review_date`, `rating`, `customer_review`; IDs R001–R030. Include varied positive, negative and mixed/neutral cases. Do not create sentiment labels or conclusions yet. Output a UTF-8 CSV. Do not include real personal information.

## 2. Initial NotebookLM analysis

> Analyse the 30 reviews using only the uploaded CSV. Classify each as Positive, Negative, Neutral or Mixed; provide review ID, star rating, sentiment, primary topic and brief reasoning. Count each sentiment. Identify three frequently mentioned issues, provide supporting IDs, and suggest three practical improvements. Distinguish fact from interpretation; flag ambiguity and do not invent evidence.

## 3. NotebookLM QA prompt

> Re-examine R024 as Neutral or Mixed and define explicit criteria for every sentiment category. Recount issue frequencies with exact source IDs; separate positive examples from negative incidents. Audit quotes, prices, waits, unsupported assumptions, and record a correction log. Do not automatically defend the previous analysis; mark unsupported conclusions as unverified.

## 4. Independent review criteria

> Before reporting findings, define non-overlapping issue *meanings* even if multiple labels apply to the same review. Count only reviews with explicit negative evidence for each issue, cite the supporting IDs, and exclude positive handling of a wait from negative delay counts. Flag subjective decisions and source limitations.

**Transparency:** Prompts 1–3 reflect the instructions used or their condensed substance; this document is a study record, not a verbatim exported chat history.
